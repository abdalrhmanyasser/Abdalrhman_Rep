x=1
y=2
z=x
print(x, y)
x=y
y=z
print(x, y)