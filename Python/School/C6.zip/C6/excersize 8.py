x=eval(input('Enter a Number: '))

for i in range(x):
    print("   "*i, i + 1)