s=input("enter a sentance")
for i in range(len(s)):
    if s[i] is "a":
        print(i)