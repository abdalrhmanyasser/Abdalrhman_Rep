s=input("input a string : ")
print(s[0] + "*" + s[2:] + "!!!")