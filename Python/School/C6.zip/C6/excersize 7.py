s=input('Enter your Name: ')

for i in range(0,len(s)):
    print(s[0:i+1])