for i in input("enter a word : "):
    print(i*2, end="")