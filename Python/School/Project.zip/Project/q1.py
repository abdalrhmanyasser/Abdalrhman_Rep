for i in input("text"):
    print(i*2)
