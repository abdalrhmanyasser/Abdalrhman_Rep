inp=input("input s for student and t for teacher : ")
if "s" == inp:
    print("st"+input("enter your student id : ")+"@saisdubai.com")
elif "t" == inp:
    print(input("enter your first name : ") + "." + input("enter your last name : ") + "@saisdubai.com")
