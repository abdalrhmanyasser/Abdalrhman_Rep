text = input("enter your text : ").split()
new_text = []
for i in text:
    new_text.append(i[0].capitalize() + i[1:])
print(" ".join(new_text))
