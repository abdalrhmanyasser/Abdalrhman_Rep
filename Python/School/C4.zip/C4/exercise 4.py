num_of_products = int(input("number of products"))
if num_of_products < 10:
    print(12 * num_of_products)
elif 10<num_of_products<=100:
    print(10*num_of_products)
elif num_of_products > 100:
    print(7*num_of_products)