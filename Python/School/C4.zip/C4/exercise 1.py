cm = int(input("enter the number in cm\n"))
if cm < 0:
    print("the number is negative!")
else:
    print(cm * 2.54)