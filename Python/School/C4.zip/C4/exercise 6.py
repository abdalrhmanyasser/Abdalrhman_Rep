num = int(input("enter a number"))
for i in range(num):
    if i %num ==0:
        print(i)