import random
print("Abdalrhman Yasser\n"*random.randint(1, 10))