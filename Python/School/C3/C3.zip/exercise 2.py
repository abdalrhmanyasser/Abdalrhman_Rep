import random
x = random.randint(1, 50)
y = random.randint(2, 5)
print(x**y)