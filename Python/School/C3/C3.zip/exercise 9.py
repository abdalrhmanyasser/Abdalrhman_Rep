import math
num=int(input("num"))
print("cos :", 360*math.cos(num), "sin :", 360*math.sin(num), "tan :", 360*math.tan(num))