import random
for i in range(50):
    print(random.randint(3, 6))