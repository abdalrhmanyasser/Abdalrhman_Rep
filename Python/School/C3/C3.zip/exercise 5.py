import random
for i in range(1, 50):
    print(random.randint(0, i))