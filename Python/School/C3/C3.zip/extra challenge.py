for i in range(200):
    if i % 5 == 2 and i % 6 == 3 and i % 7 == 2: print(i)