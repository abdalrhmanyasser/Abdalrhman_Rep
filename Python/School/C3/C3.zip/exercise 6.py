sec = eval(input("input secs"))
print(sec, "seconds", sec//60, "min", sec%60, "sec")