import random
print(random.randint(1, 9) + random.random())